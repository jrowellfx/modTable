# About modTable

`modTable` prints the addition and multiplication tables for
the ring of integers modulo n, denoted &#8484;/n&#8484;. The ring of integers
modulo n is a field, if and only if n is prime.
